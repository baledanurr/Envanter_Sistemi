<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Envanter ve Talep Sistemi</title>
    <link rel="stylesheet" href="/EnvanterSistemi/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <header class="p-4 text-center text-white" style="background: linear-gradient(90deg, #0d6efd, #6610f2); box-shadow: 0 2px 6px rgba(0,0,0,0.2);">
        <h1 style="font-weight: 600; letter-spacing: 1px;">📋 Envanter ve Talep Sistemi</h1>
    </header>

    <main class="container mt-4">





