    </main>
    <footer>
        <hr>
        <p style="text-align: center;">&copy; 2025 Envanter ve Talep Sistemi</p>
    </footer>
</body>
</html>


